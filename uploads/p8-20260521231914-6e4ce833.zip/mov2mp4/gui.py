#!/usr/bin/env python3
import sys
from pathlib import Path
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QPushButton, QLabel, QComboBox,
                             QFileDialog, QListWidget, QProgressBar, QTextEdit,
                             QGroupBox, QMessageBox, QSplitter, QTableWidget,
                             QTableWidgetItem, QHeaderView, QMenuBar, QAction)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor

from converter import convert_video, get_video_info, SUPPORTED_FORMATS


VIDEO_EXTENSIONS = "*.mp4 *.avi *.mkv *.mov *.wmv *.flv *.webm *.ts *.MP4 *.AVI *.MKV *.MOV *.WMV *.FLV *.WEBM *.TS"


TRANSLATIONS = {
    'en': {
        'window_title': 'Video Format Converter',
        'input_files': 'Input Files',
        'add_files': 'Add Files',
        'add_dir': 'Add Directory',
        'clear': 'Clear',
        'files_count': 'Files: {}',
        'filename': 'Filename',
        'format': 'Format',
        'resolution': 'Resolution',
        'codecs': 'Codecs',
        'duration': 'Duration',
        'output_settings': 'Output Settings',
        'output_dir': 'Output Directory:',
        'same_as_input': 'Same as input',
        'browse': 'Browse...',
        'output_format': 'Output Format:',
        'quality': 'Quality:',
        'convert_all': 'Convert All',
        'convert_selected': 'Convert Selected',
        'donate': 'Donate',
        'about_us': 'About Us',
        'select_video_files': 'Select Video Files',
        'select_directory': 'Select Directory',
        'select_output_dir': 'Select Output Directory',
        'warning': 'Warning',
        'no_files': 'No files selected!',
        'complete': 'Complete',
        'conversion_finished': 'Conversion finished!',
        'donate_title': 'Donate',
        'donate_text': 'Support Our Development',
        'donate_info': 'If you find this tool helpful, please consider making a donation.\n\nYour support helps us continue developing and improving this software.\n\nThank you for your generosity!',
        'about_title': 'About Us',
        'about_text': 'Video Format Converter',
        'about_info': 'Version: 1.0.0\n\nDeveloped by: Huajing Tech (华靖科技)\n\nA powerful video format conversion tool supporting multiple formats.\n\nCopyright © 2026 Huajing Tech. All rights reserved.',
        'menu_settings': 'Settings',
        'menu_dark_mode': 'Dark Mode',
        'menu_language': 'Language',
        'menu_help': 'Help',
        'menu_about': 'About',
        'converted': 'Converted: {}',
        'failed': 'Failed: {}',
        'error': 'Error processing {}: {}',
        'completed_summary': '\nCompleted: {}/{} files converted',
        'medium': 'medium',
        'high': 'high',
        'low': 'low',
    },
    'zh': {
        'window_title': '视频格式转换器',
        'input_files': '输入文件',
        'add_files': '添加文件',
        'add_dir': '添加目录',
        'clear': '清空',
        'files_count': '文件数: {}',
        'filename': '文件名',
        'format': '格式',
        'resolution': '分辨率',
        'codecs': '编码',
        'duration': '时长',
        'output_settings': '输出设置',
        'output_dir': '输出目录:',
        'same_as_input': '与输入相同',
        'browse': '浏览...',
        'output_format': '输出格式:',
        'quality': '质量:',
        'convert_all': '全部转换',
        'convert_selected': '转换选中',
        'donate': '捐赠',
        'about_us': '关于我们',
        'select_video_files': '选择视频文件',
        'select_directory': '选择目录',
        'select_output_dir': '选择输出目录',
        'warning': '警告',
        'no_files': '未选择文件！',
        'complete': '完成',
        'conversion_finished': '转换完成！',
        'donate_title': '捐赠',
        'donate_text': '支持我们的开发',
        'donate_info': '如果您觉得这个工具有用，请考虑捐赠。\n\n您的支持帮助我们继续开发和改进这个软件。\n\n感谢您的慷慨！',
        'about_title': '关于我们',
        'about_text': '视频格式转换器',
        'about_info': '版本: 1.0.0\n\n开发者: 华靖科技\n\n一款支持多种格式的强大视频格式转换工具。\n\n版权所有 © 2026 华靖科技 保留所有权利。',
        'menu_settings': '设置',
        'menu_dark_mode': '深色模式',
        'menu_language': '语言',
        'menu_help': '帮助',
        'menu_about': '关于',
        'converted': '已转换: {}',
        'failed': '失败: {}',
        'error': '处理 {} 时出错: {}',
        'completed_summary': '\n完成: {}/{} 个文件已转换',
        'medium': '中等',
        'high': '高',
        'low': '低',
    }
}


DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #2b2b2b;
    color: #ffffff;
}
QGroupBox {
    background-color: #3c3c3c;
    border: 1px solid #555555;
    border-radius: 5px;
    margin-top: 10px;
    padding-top: 15px;
    color: #ffffff;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
    color: #ffffff;
}
QPushButton {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #555555;
    padding: 8px 16px;
    border-radius: 4px;
}
QPushButton:hover {
    background-color: #5a5a5a;
}
QPushButton:pressed {
    background-color: #3a3a3a;
}
QPushButton:disabled {
    background-color: #3a3a3a;
    color: #666666;
}
QComboBox {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #555555;
    padding: 5px;
    border-radius: 4px;
}
QComboBox::drop-down {
    border: none;
}
QComboBox QAbstractItemView {
    background-color: #4a4a4a;
    color: #ffffff;
    selection-background-color: #5a5a5a;
}
QTableWidget {
    background-color: #3c3c3c;
    color: #ffffff;
    gridline-color: #555555;
    border: 1px solid #555555;
}
QTableWidget::item {
    padding: 5px;
    color: #ffffff;
}
QTableWidget::item:selected {
    background-color: #4a6fa5;
}
QHeaderView::section {
    background-color: #4a4a4a;
    color: #ffffff;
    border: 1px solid #555555;
    padding: 5px;
}
QTextEdit {
    background-color: #1e1e1e;
    color: #00ff00;
    border: 1px solid #555555;
    font-family: 'Consolas', 'Courier New', monospace;
}
QProgressBar {
    background-color: #3c3c3c;
    border: 1px solid #555555;
    border-radius: 4px;
    text-align: center;
    color: #ffffff;
}
QProgressBar::chunk {
    background-color: #4CAF50;
    border-radius: 3px;
}
QLabel {
    color: #ffffff;
    background-color: transparent;
}
QMenuBar {
    background-color: #2b2b2b;
    color: #ffffff;
    border-bottom: 1px solid #555555;
}
QMenuBar::item {
    padding: 5px 10px;
}
QMenuBar::item:selected {
    background-color: #4a4a4a;
}
QMenu {
    background-color: #3c3c3c;
    color: #ffffff;
    border: 1px solid #555555;
}
QMenu::item {
    padding: 5px 20px;
}
QMenu::item:selected {
    background-color: #4a6fa5;
}
QMenu::separator {
    height: 1px;
    background-color: #555555;
    margin: 5px 0;
}
QSplitter {
    background-color: #2b2b2b;
}
QSplitter::handle {
    background-color: #555555;
}
QScrollBar:vertical {
    background-color: #2b2b2b;
    width: 12px;
    border: none;
}
QScrollBar::handle:vertical {
    background-color: #5a5a5a;
    min-height: 20px;
    border-radius: 6px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar:horizontal {
    background-color: #2b2b2b;
    height: 12px;
    border: none;
}
QScrollBar::handle:horizontal {
    background-color: #5a5a5a;
    min-width: 20px;
    border-radius: 6px;
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0px;
}
"""

LIGHT_STYLE = ""


class ConversionThread(QThread):
    progress = pyqtSignal(int, int)
    log_message = pyqtSignal(str)
    error = pyqtSignal(str)
    all_finished = pyqtSignal()

    def __init__(self, files, output_dir, output_format, quality):
        super().__init__()
        self.files = files
        self.output_dir = output_dir
        self.output_format = output_format
        self.quality = quality

    def run(self):
        total = len(self.files)
        success = 0

        for i, file_path in enumerate(self.files):
            try:
                input_path = Path(file_path)
                if self.output_dir:
                    output_path = Path(self.output_dir) / input_path.with_suffix(self.output_format).name
                else:
                    output_path = None

                if convert_video(input_path, output_path, self.output_format, self.quality):
                    success += 1
                    self.log_message.emit(f"Converted: {input_path.name}")
                else:
                    self.error.emit(f"Failed: {input_path.name}")

                self.progress.emit(i + 1, total)
            except Exception as e:
                self.error.emit(f"Error processing {input_path.name}: {str(e)}")

        self.log_message.emit(f"\nCompleted: {success}/{total} files converted")
        self.all_finished.emit()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.is_dark_mode = False
        self.current_lang = 'en'
        self.files = []
        self.file_infos = {}
        self.init_ui()
        self.retranslate_ui()

    def init_ui(self):
        self.setMinimumSize(900, 700)

        menubar = self.menuBar()

        self.settings_menu = menubar.addMenu('Settings')

        self.dark_mode_action = QAction('Dark Mode', self)
        self.dark_mode_action.setCheckable(True)
        self.dark_mode_action.triggered.connect(self.toggle_dark_mode)
        self.settings_menu.addAction(self.dark_mode_action)

        self.lang_menu = self.settings_menu.addMenu('Language')

        self.lang_en_action = QAction('English', self)
        self.lang_en_action.setCheckable(True)
        self.lang_en_action.setChecked(True)
        self.lang_en_action.triggered.connect(lambda: self.set_language('en'))
        self.lang_menu.addAction(self.lang_en_action)

        self.lang_zh_action = QAction('中文', self)
        self.lang_zh_action.setCheckable(True)
        self.lang_zh_action.triggered.connect(lambda: self.set_language('zh'))
        self.lang_menu.addAction(self.lang_zh_action)

        self.help_menu = menubar.addMenu('Help')

        self.about_action = QAction('About', self)
        self.about_action.triggered.connect(self.show_about)
        self.help_menu.addAction(self.about_action)

        self.donate_action = QAction('Donate', self)
        self.donate_action.triggered.connect(self.show_donate)
        self.help_menu.addAction(self.donate_action)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        splitter = QSplitter(Qt.Vertical)
        layout.addWidget(splitter)

        top_widget = QWidget()
        top_layout = QVBoxLayout(top_widget)

        self.input_group = QGroupBox("Input Files")
        input_layout = QVBoxLayout()

        btn_layout = QHBoxLayout()
        self.btn_add_files = QPushButton("Add Files")
        self.btn_add_files.clicked.connect(self.add_files)
        self.btn_add_dir = QPushButton("Add Directory")
        self.btn_add_dir.clicked.connect(self.add_directory)
        self.btn_clear = QPushButton("Clear")
        self.btn_clear.clicked.connect(self.clear_files)

        btn_layout.addWidget(self.btn_add_files)
        btn_layout.addWidget(self.btn_add_dir)
        btn_layout.addWidget(self.btn_clear)
        btn_layout.addStretch()

        self.file_count_label = QLabel("Files: 0")
        btn_layout.addWidget(self.file_count_label)
        input_layout.addLayout(btn_layout)

        self.file_table = QTableWidget()
        self.file_table.setColumnCount(5)
        self.file_table.setHorizontalHeaderLabels(["Filename", "Format", "Resolution", "Codecs", "Duration"])
        self.file_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.file_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        self.file_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeToContents)
        self.file_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.file_table.setAlternatingRowColors(True)
        input_layout.addWidget(self.file_table)

        self.input_group.setLayout(input_layout)
        top_layout.addWidget(self.input_group)

        self.settings_group = QGroupBox("Output Settings")
        settings_layout = QHBoxLayout()

        self.lbl_output_dir = QLabel("Output Directory:")
        settings_layout.addWidget(self.lbl_output_dir)
        self.output_dir_edit = QLabel("Same as input")
        self.output_dir_edit.setStyleSheet("QLabel { background-color: #f0f0f0; padding: 5px; border: 1px solid #ccc; color: #000000; }")
        settings_layout.addWidget(self.output_dir_edit, 1)

        self.btn_output_dir = QPushButton("Browse...")
        self.btn_output_dir.clicked.connect(self.select_output_dir)
        settings_layout.addWidget(self.btn_output_dir)

        self.lbl_output_format = QLabel("Output Format:")
        settings_layout.addWidget(self.lbl_output_format)
        self.format_combo = QComboBox()
        for ext, config in SUPPORTED_FORMATS.items():
            self.format_combo.addItem(f"{config['label']} ({ext})", ext)
        self.format_combo.setCurrentIndex(0)
        settings_layout.addWidget(self.format_combo)

        self.lbl_quality = QLabel("Quality:")
        settings_layout.addWidget(self.lbl_quality)
        self.quality_combo = QComboBox()
        settings_layout.addWidget(self.quality_combo)

        self.settings_group.setLayout(settings_layout)
        top_layout.addWidget(self.settings_group)

        action_layout = QHBoxLayout()
        self.btn_convert = QPushButton("Convert All")
        self.btn_convert.clicked.connect(self.start_conversion)
        self.btn_convert.setStyleSheet("QPushButton { background-color: #4CAF50; color: white; font-weight: bold; padding: 10px; }")
        action_layout.addWidget(self.btn_convert)

        self.btn_convert_selected = QPushButton("Convert Selected")
        self.btn_convert_selected.clicked.connect(self.convert_selected)
        action_layout.addWidget(self.btn_convert_selected)

        action_layout.addStretch()

        self.btn_donate = QPushButton("Donate")
        self.btn_donate.clicked.connect(self.show_donate)
        self.btn_donate.setStyleSheet("QPushButton { background-color: #FF9800; color: white; padding: 10px; }")
        action_layout.addWidget(self.btn_donate)

        self.btn_about = QPushButton("About Us")
        self.btn_about.clicked.connect(self.show_about)
        self.btn_about.setStyleSheet("QPushButton { background-color: #2196F3; color: white; padding: 10px; }")
        action_layout.addWidget(self.btn_about)

        top_layout.addLayout(action_layout)

        splitter.addWidget(top_widget)

        bottom_widget = QWidget()
        bottom_layout = QVBoxLayout(bottom_widget)

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        bottom_layout.addWidget(self.progress_bar)

        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setFont(QFont("Courier", 10))
        bottom_layout.addWidget(self.log_text)

        splitter.addWidget(bottom_widget)
        splitter.setSizes([450, 200])

        self.output_dir = None

    def retranslate_ui(self):
        t = TRANSLATIONS[self.current_lang]

        self.setWindowTitle(t['window_title'])
        self.input_group.setTitle(t['input_files'])
        self.btn_add_files.setText(t['add_files'])
        self.btn_add_dir.setText(t['add_dir'])
        self.btn_clear.setText(t['clear'])
        self.file_count_label.setText(t['files_count'].format(len(self.files)))

        header_labels = [t['filename'], t['format'], t['resolution'], t['codecs'], t['duration']]
        self.file_table.setHorizontalHeaderLabels(header_labels)

        self.settings_group.setTitle(t['output_settings'])
        self.lbl_output_dir.setText(t['output_dir'])
        if not self.output_dir:
            self.output_dir_edit.setText(t['same_as_input'])
        self.btn_output_dir.setText(t['browse'])
        self.lbl_output_format.setText(t['output_format'])
        self.lbl_quality.setText(t['quality'])

        self.quality_combo.clear()
        self.quality_combo.addItems([t['medium'], t['high'], t['low']])

        self.btn_convert.setText(t['convert_all'])
        self.btn_convert_selected.setText(t['convert_selected'])
        self.btn_donate.setText(t['donate'])
        self.btn_about.setText(t['about_us'])

        self.settings_menu.setTitle(t['menu_settings'])
        self.dark_mode_action.setText(t['menu_dark_mode'])
        self.lang_menu.setTitle(t['menu_language'])
        self.help_menu.setTitle(t['menu_help'])
        self.about_action.setText(t['menu_about'])
        self.donate_action.setText(t['donate'])

    def toggle_dark_mode(self):
        self.is_dark_mode = self.dark_mode_action.isChecked()
        if self.is_dark_mode:
            QApplication.instance().setStyleSheet(DARK_STYLE)
            self.output_dir_edit.setStyleSheet("QLabel { background-color: #4a4a4a; padding: 5px; border: 1px solid #555555; color: #ffffff; }")
            self.log_text.setStyleSheet("QTextEdit { background-color: #1e1e1e; color: #00ff00; border: 1px solid #555555; font-family: 'Consolas', 'Courier New', monospace; }")
        else:
            QApplication.instance().setStyleSheet(LIGHT_STYLE)
            self.output_dir_edit.setStyleSheet("QLabel { background-color: #f0f0f0; padding: 5px; border: 1px solid #ccc; color: #000000; }")
            self.log_text.setStyleSheet("")

    def set_language(self, lang):
        self.current_lang = lang
        self.lang_en_action.setChecked(lang == 'en')
        self.lang_zh_action.setChecked(lang == 'zh')
        self.retranslate_ui()

    def get_quality_value(self):
        t = TRANSLATIONS[self.current_lang]
        quality_text = self.quality_combo.currentText()
        for key, value in t.items():
            if value == quality_text and key in ['medium', 'high', 'low']:
                return key
        return 'medium'

    def add_files(self):
        t = TRANSLATIONS[self.current_lang]
        files, _ = QFileDialog.getOpenFileNames(
            self, t['select_video_files'], "",
            f"Video Files ({VIDEO_EXTENSIONS});;All Files (*)"
        )
        if files:
            self.files.extend(files)
            self.update_file_list()

    def add_directory(self):
        t = TRANSLATIONS[self.current_lang]
        directory = QFileDialog.getExistingDirectory(self, t['select_directory'])
        if directory:
            for ext in SUPPORTED_FORMATS:
                self.files.extend([str(f) for f in Path(directory).glob(f"*{ext}")])
                self.files.extend([str(f) for f in Path(directory).glob(f"*{ext.upper()}")])
            self.files = list(dict.fromkeys(self.files))
            self.update_file_list()

    def clear_files(self):
        self.files.clear()
        self.file_infos.clear()
        self.file_table.setRowCount(0)
        t = TRANSLATIONS[self.current_lang]
        self.file_count_label.setText(t['files_count'].format(0))

    def update_file_list(self):
        t = TRANSLATIONS[self.current_lang]
        self.file_table.setRowCount(len(self.files))
        self.file_count_label.setText(t['files_count'].format(len(self.files)))

        for i, file_path in enumerate(self.files):
            input_path = Path(file_path)
            self.file_table.setItem(i, 0, QTableWidgetItem(input_path.name))

            info = get_video_info(file_path)
            if info:
                self.file_infos[file_path] = info
                self.file_table.setItem(i, 1, QTableWidgetItem(info['format'].upper()))
                self.file_table.setItem(i, 2, QTableWidgetItem(f"{info['video_width']}x{info['video_height']}"))
                self.file_table.setItem(i, 3, QTableWidgetItem(f"{info['video_codec']}/{info['audio_codec']}"))
                duration = info['duration']
                self.file_table.setItem(i, 4, QTableWidgetItem(f"{int(duration//60)}:{int(duration%60):02d}"))
            else:
                self.file_table.setItem(i, 1, QTableWidgetItem(input_path.suffix.upper()))
                self.file_table.setItem(i, 2, QTableWidgetItem("N/A"))
                self.file_table.setItem(i, 3, QTableWidgetItem("N/A"))
                self.file_table.setItem(i, 4, QTableWidgetItem("N/A"))

    def select_output_dir(self):
        t = TRANSLATIONS[self.current_lang]
        directory = QFileDialog.getExistingDirectory(self, t['select_output_dir'])
        if directory:
            self.output_dir = directory
            self.output_dir_edit.setText(directory)

    def start_conversion(self):
        t = TRANSLATIONS[self.current_lang]
        if not self.files:
            QMessageBox.warning(self, t['warning'], t['no_files'])
            return
        self.convert_files(self.files)

    def convert_selected(self):
        t = TRANSLATIONS[self.current_lang]
        selected_rows = set()
        for item in self.file_table.selectedItems():
            selected_rows.add(item.row())

        if not selected_rows:
            QMessageBox.warning(self, t['warning'], t['no_files'])
            return

        selected_files = [self.files[row] for row in sorted(selected_rows)]
        self.convert_files(selected_files)

    def convert_files(self, files):
        self.btn_convert.setEnabled(False)
        self.btn_convert_selected.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.log_text.clear()

        quality = self.get_quality_value()
        output_format = self.format_combo.currentData()

        self.thread = ConversionThread(files, self.output_dir, output_format, quality)
        self.thread.progress.connect(self.update_progress)
        self.thread.log_message.connect(self.log_message)
        self.thread.error.connect(self.conversion_error)
        self.thread.all_finished.connect(self.conversion_complete)
        self.thread.start()

    def update_progress(self, current, total):
        self.progress_bar.setValue(int(current / total * 100))

    def log_message(self, message):
        self.log_text.append(message)

    def conversion_error(self, message):
        self.log_text.append(f"ERROR: {message}")

    def conversion_complete(self):
        t = TRANSLATIONS[self.current_lang]
        self.btn_convert.setEnabled(True)
        self.btn_convert_selected.setEnabled(True)
        self.progress_bar.setVisible(False)
        QMessageBox.information(self, t['complete'], t['conversion_finished'])

    def show_donate(self):
        t = TRANSLATIONS[self.current_lang]
        msg = QMessageBox(self)
        msg.setWindowTitle(t['donate_title'])
        msg.setIcon(QMessageBox.Information)
        msg.setText(t['donate_text'])
        msg.setInformativeText(t['donate_info'])
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()

    def show_about(self):
        t = TRANSLATIONS[self.current_lang]
        msg = QMessageBox(self)
        msg.setWindowTitle(t['about_title'])
        msg.setIcon(QMessageBox.Information)
        msg.setText(t['about_text'])
        msg.setInformativeText(t['about_info'])
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
