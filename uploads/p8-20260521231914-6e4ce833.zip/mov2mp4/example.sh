#!/bin/bash
# Example usage of Video Format Converter

echo "=== Video Format Converter Examples ==="
echo ""

# Example 1: Basic conversion
echo "1. Basic conversion (MOV to MP4):"
echo "   python converter.py video.mov"
echo ""

# Example 2: Specify output format
echo "2. Convert MOV to MKV:"
echo "   python converter.py video.mov output.mkv"
echo ""

# Example 3: High quality conversion
echo "3. High quality conversion:"
echo "   python converter.py video.mov video_hq.mp4 high"
echo ""

# Example 4: View video info
echo "4. View video information:"
echo "   python converter.py video.mov"
echo ""

# Example 5: Batch convert
echo "5. Batch convert all MOV files to MP4:"
echo "   python batch_converter.py '*.mov'"
echo ""

# Example 6: Batch convert with output directory and format
echo "6. Batch convert AVI to MKV:"
echo "   python batch_converter.py '*.avi' ./output mkv high"
echo ""

# Example 7: Using shell loop
echo "7. Using shell loop:"
echo "   for f in *.mov; do python converter.py \"\$f\"; done"
echo ""

echo "=== Supported Output Formats ==="
echo "  MP4   - H.264/AAC (most compatible)"
echo "  AVI   - H.264/MP3"
echo "  MKV   - H.264/AAC (open format)"
echo "  MOV   - H.264/AAC (Apple format)"
echo "  WMV   - WMV2/WMA2 (Windows Media)"
echo "  FLV   - FLV/AAC (Flash Video)"
echo "  WebM  - VP8/Vorbis (web optimized)"
echo "  TS    - H.264/AAC (broadcast)"
echo ""

echo "=== Quality Options ==="
echo "  high   - Best quality, larger file size"
echo "  medium - Balanced (default)"
echo "  low    - Smaller file size, lower quality"
echo ""

echo "=== Launch GUI ==="
echo "  python gui.py"
