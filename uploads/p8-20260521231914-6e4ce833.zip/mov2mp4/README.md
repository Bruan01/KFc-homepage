# Video Format Converter

A Python tool to convert video files between multiple formats using ffmpeg.

## Requirements

- Python 3.6+
- ffmpeg (must be installed and in PATH)
- PyQt5 (for GUI version)

## Installation

1. Install ffmpeg (if not already installed):
   ```bash
   # macOS
   brew install ffmpeg

   # Ubuntu/Debian
   sudo apt install ffmpeg

   # Windows
   # Download from https://ffmpeg.org/download.html
   ```

2. Clone or download this project

## Supported Formats

| Format | Extension | Video Codec | Audio Codec |
|--------|-----------|-------------|-------------|
| MP4    | .mp4      | H.264       | AAC         |
| AVI    | .avi      | H.264       | MP3         |
| MKV    | .mkv      | H.264       | AAC         |
| MOV    | .mov      | H.264       | AAC         |
| WMV    | .wmv      | WMV2        | WMA2        |
| FLV    | .flv      | FLV         | AAC         |
| WebM   | .webm     | VP8         | Vorbis      |
| TS     | .ts       | H.264       | AAC         |

## Command Line Usage

### Basic conversion
```bash
python converter.py input.mov
```

### Specify output format
```bash
python converter.py input.mov output.mkv
```

### Specify quality
```bash
python converter.py input.mov output.mp4 high
```

### View file info
```bash
python converter.py input.mov
```

### Quality Options
- `high` - CRF 18, slow preset (larger file, better quality)
- `medium` - CRF 23, medium preset (default, balanced)
- `low` - CRF 28, fast preset (smaller file, lower quality)

## Batch Conversion

### Convert all MOV files to MP4
```bash
python batch_converter.py '*.mov'
```

### Convert with output directory
```bash
python batch_converter.py '*.mov' ./output mp4 high
```

### Convert AVI to MKV
```bash
python batch_converter.py '*.avi' ./converted mkv
```

## GUI Version

A graphical user interface is available using PyQt5.

### Install PyQt5
```bash
pip install PyQt5
```

### Launch GUI
```bash
python gui.py
```

### GUI Features
- Auto-detect input file format and display file info
- Select output format from dropdown (MP4, AVI, MKV, MOV, WMV, FLV, WebM, TS)
- Add individual files or entire directories
- Select output directory
- Choose quality preset (high/medium/low)
- Convert all files or selected files
- Progress bar and conversion log
- Real-time status updates

## Examples

```bash
# Convert MOV to MP4 (default)
python converter.py video.mov

# Convert MOV to MKV
python converter.py video.mov output.mkv

# Convert with high quality
python converter.py video.mov video_hq.mp4 high

# View video information
python converter.py video.mov

# Batch convert all MOV files to MP4
python batch_converter.py '*.mov'

# Batch convert AVI to MKV with output directory
python batch_converter.py '*.avi' ./output mkv

# Convert all MOV files in current directory (shell loop)
for f in *.mov; do python converter.py "$f"; done
```
