#!/usr/bin/env python3
import subprocess
import sys
import json
from pathlib import Path

SUPPORTED_FORMATS = {
    '.mp4': {'video': 'libx264', 'audio': 'aac', 'label': 'MP4'},
    '.avi': {'video': 'libx264', 'audio': 'mp3', 'label': 'AVI'},
    '.mkv': {'video': 'libx264', 'audio': 'aac', 'label': 'MKV'},
    '.mov': {'video': 'libx264', 'audio': 'aac', 'label': 'MOV'},
    '.wmv': {'video': 'wmv2', 'audio': 'wmav2', 'label': 'WMV'},
    '.flv': {'video': 'flv', 'audio': 'aac', 'label': 'FLV'},
    '.webm': {'video': 'libvpx', 'audio': 'libvorbis', 'label': 'WebM'},
    '.ts': {'video': 'libx264', 'audio': 'aac', 'label': 'TS'},
}

QUALITY_PRESETS = {
    "high": "-crf 18 -preset slow",
    "medium": "-crf 23 -preset medium",
    "low": "-crf 28 -preset fast",
}


def get_video_info(input_path):
    """Get video file information using ffprobe."""
    input_path = Path(input_path)
    if not input_path.exists():
        return None

    cmd = [
        "ffprobe",
        "-v", "quiet",
        "-print_format", "json",
        "-show_format",
        "-show_streams",
        str(input_path)
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        info = json.loads(result.stdout)

        video_stream = None
        audio_stream = None
        for stream in info.get('streams', []):
            if stream.get('codec_type') == 'video' and not video_stream:
                video_stream = stream
            elif stream.get('codec_type') == 'audio' and not audio_stream:
                audio_stream = stream

        format_info = info.get('format', {})
        duration = float(format_info.get('duration', 0))
        size = int(format_info.get('size', 0))

        return {
            'format': input_path.suffix.lower(),
            'format_name': format_info.get('format_name', 'unknown'),
            'duration': duration,
            'size': size,
            'video_codec': video_stream.get('codec_name', 'unknown') if video_stream else 'none',
            'video_width': int(video_stream.get('width', 0)) if video_stream else 0,
            'video_height': int(video_stream.get('height', 0)) if video_stream else 0,
            'audio_codec': audio_stream.get('codec_name', 'unknown') if audio_stream else 'none',
        }
    except (subprocess.CalledProcessError, json.JSONDecodeError, KeyError):
        return {
            'format': input_path.suffix.lower(),
            'format_name': 'unknown',
            'duration': 0,
            'size': 0,
            'video_codec': 'unknown',
            'video_width': 0,
            'video_height': 0,
            'audio_codec': 'unknown',
        }


def convert_video(input_path, output_path=None, output_format=None, quality="medium"):
    """Convert video to specified format using ffmpeg."""

    input_path = Path(input_path)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}")
        return False

    if output_path is None and output_format is None:
        output_format = '.mp4'

    if output_path is None:
        output_path = input_path.with_suffix(output_format if output_format else '.mp4')
    else:
        output_path = Path(output_path)

    ext = output_path.suffix.lower()
    if ext not in SUPPORTED_FORMATS:
        print(f"Error: Unsupported output format: {ext}")
        print(f"Supported formats: {', '.join(SUPPORTED_FORMATS.keys())}")
        return False

    format_config = SUPPORTED_FORMATS[ext]
    quality_args = QUALITY_PRESETS.get(quality, QUALITY_PRESETS["medium"])

    cmd = [
        "ffmpeg",
        "-i", str(input_path),
        "-c:v", format_config['video'],
        "-c:a", format_config['audio'],
        *quality_args.split(),
        "-y",
        str(output_path)
    ]

    if ext == '.mp4':
        cmd.insert(-1, "-movflags")
        cmd.insert(-1, "+faststart")

    print(f"Converting: {input_path.name} -> {output_path.name}")
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"Success: {output_path}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error: {e.stderr}")
        return False


def convert_mov_to_mp4(input_path, output_path=None, quality="medium"):
    """Legacy function for backward compatibility."""
    return convert_video(input_path, output_path, '.mp4', quality)


def main():
    if len(sys.argv) < 2:
        print("Usage: python converter.py <input> [output] [quality]")
        print("Quality options: high, medium (default), low")
        print(f"Supported output formats: {', '.join(SUPPORTED_FORMATS.keys())}")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2] if len(sys.argv) > 2 else None
    quality = sys.argv[3] if len(sys.argv) > 3 else "medium"

    info = get_video_info(input_file)
    if info:
        print(f"Input: {input_file}")
        print(f"  Format: {info['format_name']}")
        print(f"  Resolution: {info['video_width']}x{info['video_height']}")
        print(f"  Video: {info['video_codec']}, Audio: {info['audio_codec']}")
        print(f"  Duration: {info['duration']:.1f}s, Size: {info['size']/1024/1024:.1f}MB")
        print()

    success = convert_video(input_file, output_file, quality=quality)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
