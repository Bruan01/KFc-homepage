#!/usr/bin/env python3
import sys
import glob
from pathlib import Path
from converter import convert_video, SUPPORTED_FORMATS


def batch_convert(input_pattern="*.mp4", output_dir=None, output_format=None, quality="medium"):
    """Convert multiple video files to specified format."""

    files = glob.glob(input_pattern)
    if not files:
        print(f"No files found matching: {input_pattern}")
        return

    if output_format and not output_format.startswith('.'):
        output_format = '.' + output_format

    if output_format and output_format not in SUPPORTED_FORMATS:
        print(f"Error: Unsupported output format: {output_format}")
        print(f"Supported formats: {', '.join(SUPPORTED_FORMATS.keys())}")
        return

    print(f"Found {len(files)} file(s) to convert")

    success_count = 0
    for file_path in files:
        input_path = Path(file_path)

        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            out_ext = output_format if output_format else input_path.suffix
            output_path = output_dir / input_path.with_suffix(out_ext).name
        else:
            output_path = None

        if convert_video(input_path, output_path, output_format, quality):
            success_count += 1

    print(f"\nCompleted: {success_count}/{len(files)} files converted")


def main():
    if len(sys.argv) < 2:
        print("Usage: python batch_converter.py <pattern> [output_dir] [output_format] [quality]")
        print(f"Supported formats: {', '.join(SUPPORTED_FORMATS.keys())}")
        print("Examples:")
        print("  python batch_converter.py '*.mov'")
        print("  python batch_converter.py '*.mov' ./output mp4 high")
        print("  python batch_converter.py '*.avi' ./converted mkv")
        sys.exit(1)

    pattern = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    output_format = sys.argv[3] if len(sys.argv) > 3 else None
    quality = sys.argv[4] if len(sys.argv) > 4 else "medium"

    batch_convert(pattern, output_dir, output_format, quality)


if __name__ == "__main__":
    main()
