#!/bin/bash
# Launch the Video Format Converter GUI

echo "Starting Video Format Converter GUI..."
python3 gui.py
